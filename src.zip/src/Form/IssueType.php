<?php

namespace App\Form;

use App\Entity\Issue;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class IssueType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('title', null, ['required' => false])
            ->add('description', null, ['required' => false])
            ->add(
                'createdAt',
                DateTimeType::class,
                [
                    'required' => false,
                    'widget' => 'single_text'
                ]
            )
            ->add('solved',
                ChoiceType::class,
                [
                    'choices' => [
                        'No' => 0,
                        'Sí' => 1,
                    ],
                    'expanded' => true,
                    'required' => true,
                ])
            ->add('category');
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Issue::class,
        ]);
    }
}
