<?php

namespace App\Controller;

use App\Entity\Issue;
use App\Form\IssueType;
use App\Repository\IssueRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/issue")
 */
class IssueController extends AbstractController
{
    /**
     * @Route("/", name="issue_index", methods={"GET"})
     */
    public function index(IssueRepository $issueRepository): Response
    {
        return $this->render('issue/index.html.twig', [
            'issues' => $issueRepository->findAll(),
        ]);
    }

    /**
     * @Route("/new", name="issue_new", methods={"GET","POST"})
     */
    public function new(Request $request): Response
    {
        $issue = new Issue();
        $form = $this->createForm(IssueType::class, $issue);
        $form->handleRequest($request);

        if ($form->isSubmitted()) {
            if ($form->isValid()) {
                $entityManager = $this->getDoctrine()->getManager();
                $entityManager->persist($issue);
                $entityManager->flush();

                $this->addFlash(
                    'success',
                    'Se ha creado correctamente'
                );

                return $this->redirectToRoute('issue_show', [
                    'id' => $issue->getId(),
                ]);
            } else {
                $this->addFlash(
                    'notice',
                    'Se han producido errores, revise el formulario.'
                );
            }
        }

        return $this->render('issue/new.html.twig', [
            'issue' => $issue,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="issue_show", methods={"GET"})
     */
    public function show(Issue $issue): Response
    {
        $oldIssue = clone $issue;


        return $this->render('issue/show.html.twig', [
            'issue' => $issue,
        ]);
    }

    /**
     * @Route("/{id}/edit", name="issue_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, Issue $issue): Response
    {
        $form = $this->createForm(IssueType::class, $issue);
        $form->handleRequest($request);

        if ($form->isSubmitted()) {
            if ($form->isValid()) {
                $this->getDoctrine()->getManager()->flush();

                $this->addFlash(
                    'success',
                    'Se ha modificado correctamente'
                );

                return $this->redirectToRoute('issue_show', [
                    'id' => $issue->getId(),
                ]);
            } else {
                $this->addFlash(
                    'notice',
                    'Se han producido errores, revise el formulario.'
                );
            }
        }

        return $this->render('issue/edit.html.twig', [
            'issue' => $issue,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}/delete", name="issue_delete", methods={"GET"})
     */
    public function delete(Request $request, Issue $issue): Response
    {
        $entityManager = $this->getDoctrine()->getManager();
        $entityManager->remove($issue);
        $entityManager->flush();

        return $this->redirectToRoute('issue_index');
    }
}
